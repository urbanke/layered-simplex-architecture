"""Pinned external scientific implementations."""
