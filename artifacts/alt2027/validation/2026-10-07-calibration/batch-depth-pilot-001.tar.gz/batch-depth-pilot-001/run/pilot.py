"""Bounded fixed-input paper-domain batching validation, not a production run."""
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import time

import numpy as np

from lsa.alt.batch_depth import BatchedDepthEvaluator
from lsa.alt.depth import DepthEvaluator, StoreConfig

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def main():
    if (OUT / "config.json").exists():
        raise RuntimeError("immutable pilot already started")
    sources = [ROOT / "src/lsa/alt" / name for name in ("batch_depth.py", "baselines.py", "depth.py")]
    sources += sorted((ROOT / "src/lsa/alt/_vendor/pmwm").glob("*.py"))
    sources += [ROOT / "src/lsa/alt/_vendor/pmwm/provenance.json", Path(__file__).resolve()]
    source_hashes = {str(path.relative_to(ROOT)): sha(path) for path in sources}
    for path in sources:
        dest = OUT / "sources" / path.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, dest)
    write("source-hashes.json", source_hashes)
    engine_input = json.loads((ROOT / "output/alt2027/engine-candidate.json").read_text())
    engine_input["store"]["minimum_grid_step"] = .0025
    write("engine.json", engine_input)
    config = {"purpose": "bounded batch/individual numerical and timing comparison", "d": 10000,
              "n": 1000, "trials": 5, "target": "uniform", "seed": 2026100706,
              "generator": "NumPy PCG64", "depths": [0, 1, 22, 54, 80],
              "chunk_size": 5, "max_cached_profiles": 5, "single_comparison_trial": 0,
              "normalization_applied": False, "engine_sha256": sha(OUT / "engine.json"),
              "order": "store open/hash, batch preparation, cached label mapping, individual trial zero",
              "timing_scope": "single comparison reuses the same opened store; concurrent validation jobs may affect timings",
              "production_certified": False}
    write("config.json", config)
    write("environment.json", {"platform": platform.platform(), "python": platform.python_version(),
                               "numpy": np.__version__, "cpu_count": os.cpu_count(),
                               "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()})
    rng = np.random.Generator(np.random.PCG64(config["seed"]))
    target = np.full(config["d"], 1 / config["d"])
    counts = rng.multinomial(config["n"], target, size=config["trials"])
    np.savez_compressed(OUT / "samples.npz", target=target, counts=counts)
    write("samples.json", {"sha256": sha(OUT / "samples.npz"), "rng_final_state": rng.bit_generator.state,
                           "max_counts": counts.max(axis=1).tolist(),
                           "support_sizes": (counts > 0).sum(axis=1).tolist()})
    start = time.perf_counter()
    engine = DepthEvaluator(mode=engine_input["mode"], store=StoreConfig(**engine_input["store"]),
                            prediction_tolerance=engine_input["prediction_tolerance"], purpose="validation")
    open_seconds = time.perf_counter() - start
    write("effective-engine.json", engine.configuration)
    adapter = BatchedDepthEvaluator(engine, chunk_size=config["chunk_size"], max_cached_profiles=config["max_cached_profiles"])
    write("adapter.json", adapter.configuration)
    print("saved inputs; opened pinned store in", open_seconds, "seconds", flush=True)
    start = time.perf_counter()
    preparation = adapter.prepare_predictions(counts, depths=config["depths"])
    prepare_seconds = time.perf_counter() - start
    print("batch complete in", prepare_seconds, "seconds", flush=True)
    start = time.perf_counter()
    results = [adapter.predict(row, depths=config["depths"]) for row in counts]
    remap_seconds = time.perf_counter() - start
    for i, result in enumerate(results):
        np.savez_compressed(OUT / f"batch-{i}.npz", component_probabilities=result.component_probabilities,
                            mixture_probabilities=result.mixture_probabilities, posterior=result.posterior,
                            component_log_evidence=result.component_log_evidence)
        write(f"batch-{i}-diagnostics.json", result.diagnostics)
    start = time.perf_counter()
    single = engine.predict(counts[0], depths=config["depths"])
    single_seconds = time.perf_counter() - start
    np.savez_compressed(OUT / "single-0.npz", component_probabilities=single.component_probabilities,
                        mixture_probabilities=single.mixture_probabilities, posterior=single.posterior,
                        component_log_evidence=single.component_log_evidence)
    write("single-0-diagnostics.json", single.diagnostics)
    differences = {name: float(np.max(np.abs(getattr(results[0], name) - getattr(single, name))))
                   for name in ("component_probabilities", "mixture_probabilities", "posterior", "component_log_evidence")}
    unchanged = source_hashes == {str(path.relative_to(ROOT)): sha(path) for path in sources}
    checks = {"source_hashes_unchanged": unchanged,
              "component_probabilities_delta_le_1e-12": differences["component_probabilities"] <= 1e-12,
              "mixture_probabilities_delta_le_1e-12": differences["mixture_probabilities"] <= 1e-12,
              "posterior_delta_le_1e-10": differences["posterior"] <= 1e-10,
              "log_evidence_delta_le_1e-8_nats": differences["component_log_evidence"] <= 1e-8}
    summary = {"status": "passed" if all(checks.values()) else "failed", "checks": checks,
               "store_open_and_hash_seconds": open_seconds, "batch_prepare_seconds": prepare_seconds,
               "batch_remap_seconds": remap_seconds, "individual_trial_zero_seconds": single_seconds,
               "batch_seconds_per_trial": (prepare_seconds + remap_seconds) / config["trials"],
               "individual_over_batch_per_trial_ratio": single_seconds / ((prepare_seconds + remap_seconds) / config["trials"]),
               "ratio_caveat": "five jointly evaluated draws versus one individual draw; exploratory throughput ratio, not a matched five-draw speedup",
               "max_absolute_deltas_trial_zero": differences, "preparation": preparation,
               "raw_component_normalization_error_max": float(max(np.max(np.abs(r.component_probabilities.sum(axis=1)-1)) for r in results)),
               "raw_mixture_normalization_error_max": float(max(abs(r.mixture_probabilities.sum()-1) for r in results)),
               "production_certified": False}
    write("summary.json", summary)
    adapter.close()
    write("artifact-hashes.json", {str(path.relative_to(OUT)): sha(path) for path in sorted(OUT.rglob("*"))
                                   if path.is_file() and path.name not in ("artifact-hashes.json", "run.log")})
    print(json.dumps(summary, indent=2), flush=True)
    if summary["status"] != "passed":
        raise ArithmeticError("batch pilot failed")


if __name__ == "__main__":
    main()
