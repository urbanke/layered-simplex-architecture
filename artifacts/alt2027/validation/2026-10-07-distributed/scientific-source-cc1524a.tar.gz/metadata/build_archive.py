"""Create immutable compressed milestone capsules and verify their payloads."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
import tempfile
from pathlib import Path

from lsa.alt.artifacts import canonical_hash, read_json, sha256, source_identity, verify_run, write_json

REPO = Path(__file__).resolve().parents[3]
BUILD = Path(__file__).resolve().parent
ARCHIVE = REPO / 'artifacts/alt2027/validation/2026-10-07-distributed'
SETUP = REPO / 'output/alt2027/scitas-setup-20261007'
RUNS = REPO / 'output/alt2027/distributed-smoke-cc1524a'
MERGED = RUNS.with_name(RUNS.name + '-merged')
REPORT = RUNS.with_name(RUNS.name + '-report')
PLAN_PATH = RUNS.with_name(RUNS.name + '-plan.json')
COMMIT = 'cc1524a636a5f1996b4fbff1668c477ed0e989b8'


def file_entry(path):
    return {'bytes': path.stat().st_size, 'sha256': sha256(path)}


def tree_files(root, prefix):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError(f'symlink in archive input: {path}')
        if path.is_file():
            result[f'{prefix}/{path.relative_to(root).as_posix()}'] = path
    return result


def capsule(name, members, scope):
    path = ARCHIVE / f'{name}.tar.gz'
    entries = {}
    with path.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=9) as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
        for name, original in sorted(members.items()):
            payload = original.read_bytes()
            entries[name] = {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o755 if original.stat().st_mode & 0o111 else 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(payload))
    for name, original in members.items():
        if file_entry(original) != entries[name]:
            raise RuntimeError(f'archive input changed during packaging: {original}')
    recovered = {}
    with tarfile.open(path, 'r:gz') as tar:
        for member in tar:
            if not member.isfile() or member.name in recovered:
                raise ValueError(f'unsafe or duplicate tar member: {member.name}')
            payload = tar.extractfile(member).read()
            recovered[member.name] = {'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}
    if recovered != entries:
        raise RuntimeError(f'capsule round-trip mismatch: {path}')
    manifest = {'schema_version': 1, 'archive': path.name, 'scope': scope,
                'archive_sha256': sha256(path), 'archive_bytes': path.stat().st_size,
                'files': entries, 'file_count': len(entries),
                'uncompressed_bytes': sum(e['bytes'] for e in entries.values()),
                'verification': 'Every compressed member was reread and its size and SHA-256 matched.'}
    manifest_path = path.with_name(path.name[:-7] + '.manifest.json')
    write_json(manifest_path, manifest)
    return {'path': path.name, **file_entry(path), 'manifest': manifest_path.name,
            'file_count': len(entries), 'uncompressed_bytes': manifest['uncompressed_bytes'], 'scope': scope}


if ARCHIVE.exists():
    raise FileExistsError(ARCHIVE)
plan = read_json(PLAN_PATH)
if read_json(RUNS / 'plan.json') != plan:
    raise ValueError('worker and launch plans differ')
expected = {job['id'] for job in plan['jobs']}
if {p.name for p in (RUNS / 'jobs').iterdir()} != expected:
    raise ValueError('job inventory differs from plan')
experiments = sorted(plan['protocol']['experiments'])
if {p.name for p in MERGED.iterdir() if p.is_dir()} != set(experiments):
    raise ValueError('merged experiment inventory differs from plan')
run_paths = [('jobs', f'campaign/jobs/{job}', RUNS / 'jobs' / job) for job in sorted(expected)]
run_paths += [('merged', f'merged/{name}', MERGED / name) for name in experiments]
run_paths += [('report', 'report', REPORT)]
verified = []
source = None
for kind, member, root in run_paths:
    record = verify_run(root)
    if record['source']['commit'] != COMMIT or record['source']['tree_sha256'] != plan['source_tree_sha256']:
        raise ValueError(f'run scientific source differs: {root}')
    if record['purpose'] != 'smoke' or record['status'] != 'complete':
        raise ValueError(f'run not completed smoke: {root}')
    source = source or record['source']
    if record['source']['files'] != source['files'] or record['source']['dirty']:
        raise ValueError('smoke run does not have one clean scientific source')
    verified.append({'kind': kind, 'capsule_path': member, 'working_path': str(root),
                     'manifest_sha256': sha256(root / 'manifest.json'), 'outputs': len(record['outputs']),
                     'status': record['status'], 'experiment': record['experiment'], 'purpose': record['purpose']})
current = source_identity(REPO)
if current['commit'] != COMMIT or current['tree_sha256'] != source['tree_sha256'] or current['files'] != source['files']:
    raise ValueError('current source bytes differ from verified execution source')
workers = [read_json(p) for p in (RUNS / 'workers').glob('*-finished.json')]
if len(workers) != 1 or workers[0]['status'] != 'complete' or workers[0]['failures'] or workers[0]['processes'] != 2:
    raise ValueError('worker completion evidence differs from milestone')
if len(workers[0]['results']) != 62 or {r['id'] for r in workers[0]['results']} != expected:
    raise ValueError('worker result inventory incomplete')
ARCHIVE.mkdir(parents=True, exist_ok=False)
write_json(ARCHIVE / 'source-identity.json', source)
original_verification = {'schema_version': 1, 'source_commit': COMMIT, 'source_tree_sha256': source['tree_sha256'],
                         'source_files': len(source['files']), 'source_matches_execution': True,
                         'source_dirty_during_execution': False, 'run_counts': {'jobs': len(expected), 'merged': len(experiments), 'reports': 1},
                         'controller_processes': 2, 'controller_workers': workers[0]['worker_count'],
                         'purpose': 'smoke', 'runs': verified}
write_json(BUILD / 'original-run-verification.json', original_verification)
excluded = {p.name: {**file_entry(p), 'working_path': str(p), 'reason': 'Bulk transfer payload; metadata retained without duplicating bytes.'}
            for p in sorted(SETUP.iterdir()) if p.is_file() and (p.suffix == '.bundle' or p.name.endswith('.tar.gz'))}
write_json(ARCHIVE / 'excluded-bulk.json', {'schema_version': 1, 'files': excluded})
source_members = {f'source/{name}': REPO / name for name in source['files']}
source_members['metadata/source-identity.json'] = ARCHIVE / 'source-identity.json'
source_members['metadata/build_archive.py'] = Path(__file__).resolve()
capsules = [capsule('scientific-source-cc1524a', source_members,
                    'Exact 178-file scientific source from clean cc1524a smoke execution; excludes artifacts/output as source_identity does.')]
smoke_members = tree_files(RUNS, 'campaign') | tree_files(MERGED, 'merged') | tree_files(REPORT, 'report')
smoke_members['launch-plan.json'] = PLAN_PATH
smoke_members['metadata/original-run-verification.json'] = BUILD / 'original-run-verification.json'
capsules.append(capsule('distributed-smoke-cc1524a', smoke_members,
                        'All 62 completed smoke jobs, their controller/specification records, nine merged experiments, and the completed report run.'))
setup_names = [
    'appendix-validation.txt', 'distributed-regression.txt', 'tests.txt',
    'jed-calibration.sbatch', 'jed-engine.json', 'jed-kernel-validation.json',
    'launch-preflight.sh', 'preflight-40152542.out', 'preflight-40152660.out',
    'probe-exact-subset.manifest.json',
]
setup_members = {f'setup/{name}': SETUP / name for name in setup_names}
setup_members.update(tree_files(SETUP / 'jed-preflight-records', 'setup/jed-preflight-records'))
setup_members['metadata/excluded-bulk.json'] = ARCHIVE / 'excluded-bulk.json'
capsules.append(capsule('scitas-preflight-and-regressions', setup_members,
                        'Saved regression/appendix logs, failed and passed Slurm preflight logs, the passed preflight JSON records, and preparation configurations. No calibration result claims.'))
with tempfile.TemporaryDirectory(prefix='verify-capsules-', dir=BUILD) as temporary:
    extracted = Path(temporary)
    with tarfile.open(ARCHIVE / 'distributed-smoke-cc1524a.tar.gz', 'r:gz') as tar:
        tar.extractall(extracted, filter='data')
    for entry in verified:
        root = extracted / entry['capsule_path']
        verify_run(root)
        if sha256(root / 'manifest.json') != entry['manifest_sha256']:
            raise ValueError('extracted Run manifest identity mismatch')
    extracted_plan = read_json(extracted / 'launch-plan.json')
    if extracted_plan != plan:
        raise ValueError('extracted plan mismatch')
verification = {**original_verification, 'compressed_member_checks': 'passed for all three capsules',
                'extracted_run_verification': {'status': 'passed', 'jobs': len(expected), 'merged': len(experiments), 'reports': 1},
                'source_capsule_tree_sha256': canonical_hash({name: sha256(REPO / name) for name in source['files']})}
write_json(ARCHIVE / 'verification.json', verification)
preflight_paths = sorted((SETUP / 'jed-preflight-records').glob('*-preflight.json'))
if len(preflight_paths) != 1:
    raise ValueError('unexpected preflight result inventory')
preflight_path = preflight_paths[0]
launch_path = preflight_path.with_name(preflight_path.name.replace('-preflight.json', '.json'))
exit_path = preflight_path.with_name(preflight_path.name.replace('-preflight.json', '-exit.json'))
preflight, launch, exit_record = map(read_json, (preflight_path, launch_path, exit_path))
if preflight['status'] != 'passed' or preflight['production_certified'] or exit_record['exit_code'] != 0 or not exit_record['source_and_inputs_unchanged']:
    raise ValueError('preflight completion/scope evidence mismatch')
if launch['actual_commit'] != COMMIT or launch['expected_commit'] != COMMIT or launch['source_tree_sha256'] != source['tree_sha256'] or launch['source_files_sha256'] != source['files']:
    raise ValueError('preflight scientific source differs from smoke source')
if sha256(SETUP / 'jed-engine.json') != launch['input_files']['engine_config']['sha256']:
    raise ValueError('preflight engine input mismatch')
store = preflight['store']
if len(store['files_sha256']) != 106 or store['bytes_verified'] != 2802407082 or store['files_sha256'] != preflight['engine_configuration']['store']['files_sha256']:
    raise ValueError('preflight store verification identity mismatch')
if any(check['status'] != 'passed' for check in [*preflight['checks'], *preflight['reference']['checks']]):
    raise ValueError('preflight check failed')
write_json(ARCHIVE / 'preflight-verification.json', {
    'schema_version': 1, 'job_id': '40152660', 'source_commit': COMMIT,
    'source_tree_sha256': source['tree_sha256'], 'source_file_count': len(source['files']),
    'status': 'passed', 'exit_code': 0, 'source_and_inputs_unchanged': True,
    'runtime': preflight['engine_configuration']['runtime'],
    'store_file_count': len(store['files_sha256']), 'store_bytes_verified': store['bytes_verified'],
    'store_content_identity_sha256': store['content_identity_sha256'],
    'store_pins_match_saved_verification': True, 'engine_input_matches_launch_hash': True,
    'checks': preflight['checks'], 'independent_reference_checks': preflight['reference']['checks'],
    'scope': preflight['scope'], 'production_certified': False,
})
readme = '''# Distributed smoke and SCITAS preflight — 7 October 2026

This milestone preserves the completed end-to-end smoke campaign and the passed
SCITAS compute-node preflight for scientific source commit
`cc1524a636a5f1996b4fbff1668c477ed0e989b8`. The 62 planned jobs completed with two
local worker processes; all nine merged experiment Runs and the report Run also
completed. Every Run inventory, file size, SHA-256 and saved protocol identity
was verified both in its working location and after extracting the capsule.
These are smoke and infrastructure checks, not production estimates.

The scientific source capsule contains the exact 178 files recorded by those
Runs, including the pinned corpora and environment lock. Its source-tree hash is
`cefc1852613bb1397a881790a7a769e75425e41c437c270eecfa9fbaec7a364d`.
The smoke capsule includes the common samples, raw trials, block diagnostics,
merged summaries, rendered reports, source-job mappings and controller records.
The records retain their original local paths; checksums establish the archived
identities independently of those paths.

The setup capsule preserves the full development regression log (374 tests and
7 subtests passed) and full appendix validation (all eight checks passed), both
from before the final job-ordering fix. The targeted distributed regression
after that fix passed 109 tests and 7 subtests. The earlier broad regression must
not be read as a full-suite run at the final commit. The defect was an
inconsistent job ordering after JSON serialization sorted experiment keys; the
final ordering fix and its regression test are included in the source capsule.

Slurm preflight job `40152542` failed at the exact-partition guard before any
numerical work. Its log is retained. Corrected preflight job `40152660` exited
zero with source and inputs unchanged. Its three JSON records preserve the
compute-node runtime and the complete numerical-store verification: all 106
files, 2,802,407,082 bytes, were checked against their declared SHA-256 values.
This verifies installation, source and store identity, not numerical accuracy
across the production domain. Calibration configurations included in the setup
capsule record preparation only; no submitted calibration outcome is claimed.

`archive-index.json` lists the three compressed capsules. Each has a per-member
size/SHA-256 manifest; `SHA256SUMS` covers all archive files except itself.
`verification.json` records all 72 verified Runs and the extraction check.
`excluded-bulk.json` preserves sizes and hashes for the two Git-transfer bundles
and the exact-reference subset tarball, whose bulk bytes are not duplicated.
The subset's own per-file manifest is retained. The full 2.80 GB store is likewise
identified by its complete preflight hash inventory rather than copied here.
Public durable retrieval remains part of the final release archive.
'''
(ARCHIVE / 'README.md').write_text(readme)
index = {'schema_version': 1, 'milestone': '2026-10-07-distributed-smoke-and-scitas-preflight',
         'source_commit': COMMIT, 'source_tree_sha256': source['tree_sha256'], 'purpose': 'smoke_and_environment_validation',
         'capsules': capsules, 'verification': 'verification.json', 'preflight_verification': 'preflight-verification.json', 'source_identity': 'source-identity.json',
         'excluded_bulk': 'excluded-bulk.json', 'production_results': False,
         'calibration_results_included': False}
write_json(ARCHIVE / 'archive-index.json', index)
checksum_lines = [f'{sha256(p)}  {p.name}' for p in sorted(ARCHIVE.iterdir()) if p.is_file()]
(ARCHIVE / 'SHA256SUMS').write_text('\n'.join(checksum_lines) + '\n')
for line in (ARCHIVE / 'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    if sha256(ARCHIVE / name) != digest:
        raise ValueError(f'checksum index mismatch: {name}')
print(json.dumps({'archive': str(ARCHIVE), 'files': len(list(ARCHIVE.iterdir())),
                  'bytes': sum(p.stat().st_size for p in ARCHIVE.iterdir()), 'capsules': capsules,
                  'verified_runs': len(verified)}, indent=2))
