# Declared kernel calibration, 7 October 2026

The configuration resolves 263 finite kernel cases at depths 2, 5, 22, 53, 54, 80, and 138. Counts include 0–3, 16, 100, 255–257, 1000, 50000, and 1045889; the exact count/depth/u combinations are in `resolved-cases.json`. The cases are reproducible replacements for undocumented historical row checks, not a reconstruction of their unknown inputs.

`rows.jsonl` records independent 45- and 60-digit Mellin contours, the corrected direct provider pointwise and in batches, halved contour spacing, the legacy saddle/series comparator, and available immutable-store rows. Residuals are natural-log kernel errors in nats. Both corrected direct modes pass all 263 declared gates. The independent references agree within 3.664e-39 nats; the largest corrected error is 1.082e-9 nats at count 1045889. For counts 0–3, the largest error is 1.452e-12 nats.

The old saddle/series shortcut fails: the largest declared error is 0.03549 nats. For depths at least 54, its largest declared low-count error is 0.03191 nats. The production high-depth provider now uses the corrected direct contour route; the legacy function remains only for explicit diagnostic comparisons.

`special-functions.json` records 36 separate 45-digit Meijer-G checks at depths 1–3, including 12 depth-two positive-recursion comparisons. Meijer-G residuals are at most 1e-44 nats. All recursion comparisons agree at the saved 45-digit precision. Generic Meijer-G evaluation was not attempted at depth 138; independent Mellin inversion covers the declared high-depth cases.

All 111 sampled anchors-store rows and 90 available probe-store rows pass the original 3e-9-nat row criterion. One shared stored row (depth 53, count 0, u=-24) misses the deliberately stricter 1e-11-nat low-count gate, with error -1.416e-11 nats. This is recorded rather than hidden. At the selected profile-peak u values -10, -0.258, and 5.2, sampled zero-count errors are at most 2.925e-14 nats. No stored files were modified.

`assessment.json` gives machine-readable aggregate results and distinguishes conditional amplification calculations from actual profile errors. If each log-kernel error is epsilon_r(u), a profile with multiplicities h_r has log-integrand error sum_r h_r epsilon_r(u). A uniform bound over the integral would bound log-evidence error, but this finite row grid alone does not establish that bound. End-to-end profile refinement and normalization remain separate checks.

Source hashes were unchanged throughout the run. `source-capsule/` preserves their exact bytes; implementation and immutable-store identities are recorded separately. This calibration supports only the declared finite grid and does not alone certify production.
