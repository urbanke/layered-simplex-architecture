import json
from pathlib import Path
from lsa.alt.depth import DepthEvaluator,StoreConfig
from lsa.alt.chain_validation import run_chain_validation
config=json.loads(Path('output/alt2027/engine-candidate.json').read_text())
protocol=json.loads(Path('experiments/alt2027/bible-chain-validation.json').read_text())
with DepthEvaluator(mode='store',store=StoreConfig(**config['store']),prediction_tolerance=.001) as evaluator:
 result=run_chain_validation(protocol,'output/alt2027/chain-pilot-20261007/all-depths',evaluator=evaluator,repo='.')
 print(json.dumps(result),flush=True)
