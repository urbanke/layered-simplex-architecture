"""Rerun both original failed cases, all declared depths, using saved profiles."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import gzip,json,os,platform,shutil,subprocess,time,traceback
import numpy as np
from lsa.alt.artifacts import sha256,write_json
from lsa.alt.benchmark import jsonable
from lsa.alt.depth import DepthEvaluator,StoreConfig
from lsa.alt.depth_validation import comparison

MAIN=Path('/Users/ruediger/Documents/Codex/2026-10-06/i-ha/work/github-cleanup')
SOURCE=MAIN.parent/'alt-window-fix'
OUT=Path(__file__).resolve().parent
ORIGINAL=MAIN/'output/alt2027/depth-calibration-20261007/shard-3'

def worker(index):
    out=OUT/f'shard-{index}';out.mkdir()
    old=json.loads((ORIGINAL/f'result-{index:03d}.json').read_text());case=old['case']
    config=json.loads((ORIGINAL/'config.json').read_text());config['cases']=[case]
    write_json(out/'config.json',config)
    original_sample=ORIGINAL/f'case-{index:03d}.npz';shutil.copyfile(original_sample,out/'case-000.npz')
    assert sha256(out/'case-000.npz')==old['sample_sha256']
    with np.load(out/'case-000.npz',allow_pickle=False) as z:counts,target=z['counts'],z['target']
    assert counts.shape==(case['d'],) and int(counts.sum())==case['n']
    sources=[SOURCE/'src/lsa/alt'/name for name in ('depth.py','depth_validation.py')]
    hashes={p.name:sha256(p) for p in sources};write_json(out/'implementation.json',hashes)
    profile=tuple(counts[counts>0]);engine=json.loads((OUT/'inputs/engine-candidate.json').read_text())
    settings=engine['store'];a=b=None;started=time.monotonic()
    record={'id':case['id'],'case':case,'sample_sha256':old['sample_sha256'],'original_failed_record_sha256':sha256(ORIGINAL/f'result-{index:03d}.json')}
    try:
        results={}
        for label in ('default','refined'):
            s=dict(settings)
            if label=='refined':s.update(config['refinement'])
            print(f'START {case["id"]} {label}',flush=True)
            with DepthEvaluator(mode='store',store=StoreConfig(**s),prediction_tolerance=config['raw_mass_tolerance']) as evaluator:
                write_json(out/f'{label}-engine.json',evaluator.configuration)
                results[label]=evaluator.prediction_by_count(case['d'],profile,depths=case['depths'])
                with gzip.open(out/f'checkpoint-{label}.json.gz','xt') as f:json.dump(jsonable(results[label]),f,allow_nan=False)
            print(f'DONE {case["id"]} {label}',flush=True)
        a,b=results['default'],results['refined']
        mass=[float(target[counts==c].sum()) for c in a.counts]
        values=comparison(a,b,n=case['n'],class_mass=mass,multiplicities=a.multiplicities)
        checks={k:config['raw_mass_tolerance'] if k=='maximum_raw_mass_error' else config['loss_tolerance_bits'] for k in ('maximum_codelength_difference_bits_per_token','mixture_codelength_difference_bits_per_token','maximum_predictive_kl_change_bits','mixture_predictive_kl_change_bits','maximum_raw_mass_error')}
        record.update(status='passed' if all(values[k]<=tol for k,tol in checks.items()) else 'failed',measurements=values)
        with gzip.open(out/'evaluation-000.json.gz','xt') as f:json.dump(jsonable(results),f,allow_nan=False)
    except Exception as exc:
        record.update(status='failed',error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
    record['source_unchanged']=all(sha256(p)==hashes[p.name] for p in sources)
    if not record['source_unchanged']:record['status']='failed'
    record['seconds']=time.monotonic()-started;write_json(out/'result-000.json',record);print(json.dumps(record),flush=True)
    write_json(out/'summary.json',{'status':record['status'],'cases':[record]})
    return record

if __name__=='__main__':
    inp=OUT/'inputs';inp.mkdir()
    for p in (MAIN/'output/alt2027/engine-candidate.json',MAIN/'experiments/alt2027/depth-validation.json',SOURCE/'requirements-alt.lock'):
        shutil.copyfile(p,inp/p.name)
    hashes={str(p.relative_to(SOURCE)):sha256(p) for p in sorted((SOURCE/'src').rglob('*')) if p.is_file() and p.suffix in ('.py','.json')}
    for name,digest in hashes.items():
        dest=OUT/'source-capsule'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/name,dest)
    write_json(OUT/'source-hashes.json',hashes)
    config=json.loads((inp/'depth-validation.json').read_text());config['cases']=[c for c in config['cases'] if c['id'] in ('uniform-n20000','dirichlet_half-n20000')];write_json(OUT/'config.json',config)
    write_json(OUT/'request.json',{'purpose':'validation','source':str(SOURCE),'source_commit':subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),'source_hashes_sha256':sha256(OUT/'source-hashes.json'),'driver_sha256':sha256(__file__),'workers':2,'saved_cases':{'2':'uniform-n20000','3':'dirichlet_half-n20000'},'original_run':str(ORIGINAL),'no_new_draws':True,'threads':{k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS')},'python':platform.python_version()})
    with ProcessPoolExecutor(max_workers=2) as pool:records=list(pool.map(worker,[2,3]))
    unchanged=all(sha256(SOURCE/name)==digest for name,digest in hashes.items())
    write_json(OUT/'summary.json',{'status':'passed' if unchanged and all(r['status']=='passed' for r in records) else 'failed','cases':records,'source_unchanged':unchanged,'scope':'Two saved failed cases, all original eight depths, repaired implementation. Actual-grid-halving assessment is separate; no production admission.'})
