from pathlib import Path
import json
from concurrent.futures import ProcessPoolExecutor
from lsa.alt.depth_validation import run_depth_validation

def worker(i):
 config=json.loads(Path('experiments/alt2027/depth-validation.json').read_text());engine=json.loads(Path('output/alt2027/engine-candidate.json').read_text())
 config['cases']=config['cases'][i::config['workers']]
 return run_depth_validation(config,Path('output/alt2027/depth-calibration-20261007')/f'shard-{i}',engine_config=engine,repo='.')

if __name__=='__main__':
 with ProcessPoolExecutor(max_workers=4) as pool:
  for i,summary in enumerate(pool.map(worker,range(4))):print('SHARD',i,summary['status'],flush=True)
