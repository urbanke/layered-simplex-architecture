"""Time independent n shards on the exact existing primary pilot samples."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import resource
import shutil
import socket
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace

import numpy as np
from lsa.alt.artifacts import Run, environment, read_json, sha256, source_identity, utc_now, verify_run, write_json
from lsa.alt.benchmark import prepare_samples, run_benchmark, validate_config
from lsa.alt.cli import make_depth

COMMIT = 'f0a5ebd0a57d46caeb9bf45407c062f37b8d64bc'
BASE = Path('/scratch/urbanke/lsa-alt2027')
REPO = BASE / 'checkouts' / COMMIT
ROOT = BASE / 'runs/throughput-nsplit-f0a5ebd-20261007-001'
ORIGINAL = BASE / 'runs/throughput-f0a5ebd-20261007-001/primary-zipf1p5-20/run/data/samples'
ORIGINAL_MANIFEST_SHA256 = 'ddfd9d10a707e49189d3b228571b58520bec9a94f5884a571655f5be9db979c1'

def main():
    nodes = subprocess.check_output(['scontrol','show','hostnames',os.environ['SLURM_JOB_NODELIST']],text=True).splitlines()
    assert socket.gethostname().split('.')[0] in {n.split('.')[0] for n in nodes}
    assert int(os.environ['SLURM_CPUS_PER_TASK']) == 1
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip() == COMMIT
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip()
    protocol = read_json(REPO/'experiments/alt2027/protocol.json')
    config = copy.deepcopy(protocol['experiments']['benchmark_primary'])
    full_ns = list(config['n_values'])
    n = full_ns[int(sys.argv[1])]
    config.update(targets=['zipf_1.5'],trials=20,trial_start=0,n_values=[n],sampling_n_values=full_ns)
    config = validate_config(config)
    protocol['experiments'] = {'benchmark_primary':config}
    name = f'primary-zipf1p5-n{n}-20'
    root = ROOT/name
    root.mkdir(parents=True,exist_ok=False)
    protocol_path = root/'protocol.json'
    write_json(protocol_path,protocol)
    engine_path = BASE/'setup/jed-engine.json'
    write_json(root/'pilot-request.json',{
        'purpose':'validation','production_admission':False,'case':name,'experiment':'benchmark_primary',
        'n':n,'trials':20,'trial_start':0,'sampling_n_values':full_ns,'batch_size':20,
        'source':source_identity(REPO),'driver_sha256':sha256(__file__),
        'engine_sha256':sha256(engine_path),'protocol_sha256':sha256(protocol_path),
        'parent_protocol_sha256':sha256(REPO/'experiments/alt2027/protocol.json'),
        'environment':environment(),'job_id':os.environ['SLURM_JOB_ID'],
        'array_job_id':os.environ.get('SLURM_ARRAY_JOB_ID'),'host':socket.gethostname(),
        'cpu_count':1,'started_utc':utc_now(),
        'original_sample_manifest_sha256':ORIGINAL_MANIFEST_SHA256,
        'sampling_note':'Consume the original full n grid, save the selected n; compare all20 count and target arrays against the original pilot before scoring.'})
    start = time.perf_counter()
    status,error = 'passed',None
    try:
        assert sha256(ORIGINAL/'manifest.json') == ORIGINAL_MANIFEST_SHA256
        old = read_json(ORIGINAL/'manifest.json')
        samples = root/'samples'
        saved = prepare_samples(config,samples)
        old_entries = {(e['target_id'],e['trial']):e for e in old['files']}
        assert {(e['target_id'],e['trial']) for e in saved['files']} == {('zipf_1.5',t) for t in range(20)}
        comparisons = []
        input_samples = []
        for entry in saved['files']:
            previous = old_entries[(entry['target_id'],entry['trial'])]
            selected_path,original_path = samples/entry['path'],ORIGINAL/previous['path']
            assert sha256(selected_path) == entry['sha256']
            assert sha256(original_path) == previous['sha256']
            with np.load(selected_path,allow_pickle=False) as selected, np.load(original_path,allow_pickle=False) as original:
                assert set(selected.files) == {'target',f'counts_{n}'}
                assert np.array_equal(selected['target'],original['target'])
                assert np.array_equal(selected[f'counts_{n}'],original[f'counts_{n}'])
            comparisons.append({'trial':entry['trial'],'target_id':entry['target_id'],
                                'selected_file':entry['path'],'selected_sha256':entry['sha256'],
                                'original_file':previous['path'],'original_sha256':previous['sha256'],
                                'target_array_identical':True,'count_array_identical':True})
            input_samples.extend([selected_path,original_path])
        comparison_path = root/'samples-comparison.json'
        write_json(comparison_path,{'status':'passed','n':n,'trials':20,
                                   'original_manifest_sha256':ORIGINAL_MANIFEST_SHA256,'comparisons':comparisons})
        evaluator = make_depth(SimpleNamespace(engine_config=engine_path,calibration=None,purpose='validation'))
        engine = {'depth':evaluator.configuration,'execution':{'batch_size':20,
                   'batch_implementation_sha256':sha256(REPO/'src/lsa/alt/batch_depth.py')}}
        try:
            with Run(root/'run',repo=REPO,protocol=protocol,experiment='benchmark_primary',purpose='validation',
                     engine_identity=engine,inputs=[protocol_path,engine_path,samples/'manifest.json',
                     ORIGINAL/'manifest.json',comparison_path,*input_samples]) as run:
                archived_samples = run.path/'data/samples'
                shutil.copytree(samples,archived_samples)
                shutil.copyfile(comparison_path,run.path/'samples-comparison.json')
                run_benchmark(config,run.path/'data',depth_evaluator=evaluator,
                              samples_dir=archived_samples,batch_size=20)
        finally:
            evaluator.close()
        verify_run(root/'run')
    except Exception:
        status,error = 'failed',traceback.format_exc()
        raise
    finally:
        usage=resource.getrusage(resource.RUSAGE_SELF)
        result={'case':name,'n':n,'status':status,'error':error,'wall_seconds':time.perf_counter()-start,
                'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,
                'peak_rss_kib':usage.ru_maxrss,'finished_utc':utc_now(),'production_admission':False}
        write_json(root/'pilot-result.json',result)
        print(json.dumps(result),flush=True)

if __name__ == '__main__':
    main()
