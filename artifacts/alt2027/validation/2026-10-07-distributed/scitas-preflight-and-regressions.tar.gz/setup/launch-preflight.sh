#!/usr/bin/env bash
set -euo pipefail
alt_commit=${1:?exact source commit required}
[[ "$alt_commit" =~ ^[0-9a-f]{40}$ ]] || exit 2
alt_base=/scratch/urbanke/lsa-alt2027
export ALT_REPO="$alt_base/checkouts/$alt_commit"
export ALT_EXPECTED_COMMIT="$alt_commit"
export ALT_PYTHON=/home/urbanke/venvs/alt2027-py313-20261007/bin/python
export ALT_ENGINE_CONFIG="$alt_base/setup/jed-engine.json"
export ALT_PLAN="$alt_base/setup/validation-plan-$alt_commit.json"
export ALT_OUT="$alt_base/runs/preflight-$alt_commit"
export PYTHONPATH="$ALT_REPO/src"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
mkdir -p "$alt_base/checkouts" "$alt_base/runs" /scratch/urbanke/alt2027-logs
test ! -e "$ALT_REPO"
git clone --quiet --branch alt/experiment-pipeline "$alt_base/setup/source-$alt_commit.bundle" "$ALT_REPO"
git -C "$ALT_REPO" remote set-url origin git@github.com:urbanke/layered-simplex-architecture.git
test "$(git -C "$ALT_REPO" rev-parse HEAD)" = "$alt_commit"
"$ALT_PYTHON" "$ALT_REPO/scripts/alt_distributed.py" prepare \
  --repo "$ALT_REPO" --protocol "$ALT_REPO/experiments/alt2027/smoke.json" \
  --purpose validation --engine-config "$ALT_ENGINE_CONFIG" --out "$ALT_PLAN"
sbatch --parsable "$ALT_REPO/cluster/alt2027/jed-preflight.sbatch"
