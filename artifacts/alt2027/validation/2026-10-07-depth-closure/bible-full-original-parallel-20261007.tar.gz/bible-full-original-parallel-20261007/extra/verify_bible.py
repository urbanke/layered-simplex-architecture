"""Independent record/assembly verification after the parallel driver exits."""
from pathlib import Path
import copy,gzip,hashlib,json,math
from datetime import datetime,timezone
import numpy as np
ROOT=Path('/Users/ruediger/Documents/Codex/2026-10-06/i-ha/work/github-cleanup')
RUN=ROOT/'output/alt2027/bible-full-original-parallel-20261007'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def engine_hash(value):return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()
def mixed(logs):
 a=np.asarray(logs,dtype=float);m=float(a.max());return m+math.log(float(np.exp(a-m).sum()))-math.log(len(a))
def main():
 summary=read(RUN/'summary.json');request=read(RUN/'request.json')
 assert summary['status']=='passed' and summary['source_unchanged']
 assert sha(RUN/'run.py')==request['driver_sha256']
 assert sha(RUN/'source-hashes.json')==request['source_hash_manifest_sha256']
 engines={label:read(RUN/'inputs'/f'{label}-engine.json') for label in ('default','refined')}
 hashes=read(RUN/'source-hashes.json')
 for absolute,digest in hashes.items():
  p=Path(absolute);assert sha(p)==digest
  rel=p.relative_to(ROOT.parent/'alt-pilot-d1e4d26');assert sha(RUN/'source-capsule'/rel)==digest
 for r in read(RUN/'input-manifest.json'):
  assert sha(RUN/r['snapshot'])==r['sha256'] and sha(r['source'])==r['sha256']
 with np.load(RUN/'inputs/case-006.npz',allow_pickle=False) as z:
  counts=z['counts'];assert counts.shape==(100000,) and int(counts.sum())==915860
 assert sha(RUN/'inputs/case-006.npz')==summary['sample_sha256']==request['sample_sha256']
 depths=list(range(55))
 with gzip.open(RUN/'evaluation-supplemented.json.gz','rt') as f:assembled=json.load(f)
 posterior_checks={}
 for label,value in assembled.items():
  assert value['depths']==depths and len(value['log_evidence'])==len(value['diagnostics']['components'])==55
  for i,depth in enumerate(depths):
   assert value['diagnostics']['components'][i]['depth']==depth
   p=RUN/'checkpoints'/f'depth-{depth:02d}-{label}.json'
   if label=='supplement' and not p.exists():p=RUN/'checkpoints'/f'depth-{depth:02d}-refined.json'
   checkpoint=read(p);row=checkpoint['result'];assert row['depths']==[depth]
   effective_label=p.name.removesuffix('.json').split('-')[-1]
   if effective_label=='supplement':
    engine=checkpoint['engine'];expected=copy.deepcopy(engines['refined'])
    default=read(RUN/'checkpoints'/f'depth-{depth:02d}-default.json')['result']['diagnostics']['components'][0]
    refined=read(RUN/'checkpoints'/f'depth-{depth:02d}-refined.json')['result']['diagnostics']['components'][0]
    x,y=default['outer_grid_step'],refined['outer_grid_step'];assert y>.51*x
    step=min(x,y)/2;expected['store']['grid_step']=step;expected['store']['minimum_grid_step']=min(expected['store']['minimum_grid_step'],step)
    assert engine==expected
   else:engine=engines[effective_label]
   assert checkpoint['engine_sha256']==row['diagnostics']['configuration_sha256']==engine_hash(engine)
   assert value['log_evidence'][i]==row['log_evidence'][0]
   assert value['diagnostics']['components'][i]==row['diagnostics']['components'][0]
  logs=np.asarray(value['log_evidence']);assert np.isfinite(logs).all()
  posterior=read(RUN/f'{label}-posterior.json');weights=np.exp(logs-logs.max());weights/=weights.sum()
  saved_weights=np.asarray(posterior['posterior']);assert np.isfinite(saved_weights).all() and np.all(saved_weights>=0)
  saved_mass=float(saved_weights.sum());assert saved_mass>0
  discrepancy=float(np.max(np.abs(weights-saved_weights)))
  rounding_tolerance=max(2e-12,4*abs(float(np.spacing(logs.max()))))
  assert discrepancy<=rounding_tolerance
  relative_discrepancy=float(np.max(np.abs(weights-saved_weights/saved_mass)))
  assert relative_discrepancy<2e-12
  posterior_checks[label]={'maximum_absolute_discrepancy':discrepancy,'floating_scale_tolerance':rounding_tolerance,'saved_posterior_sum':saved_mass,'maximum_discrepancy_after_normalizing_saved_weights':relative_discrepancy,'relative_weight_tolerance':2e-12}
  assert abs(mixed(logs)-posterior['mixture_log_evidence_nats'])<2e-9
  assert abs(logs[0]+915860*math.log(100000))<1e-8
  analytic=math.lgamma(100000)-math.lgamma(100000+915860)+sum(math.lgamma(int(c)+1) for c in sorted(counts[counts>0],reverse=True))
  assert abs(logs[1]-analytic)<1e-8
 for label,a,b in [('original','default','refined'),('supplemental','refined','supplement'),('final','default','supplement')]:
  x=np.asarray(assembled[a]['log_evidence']);y=np.asarray(assembled[b]['log_evidence']);delta=float(np.max(abs(x-y)))/math.log(2)
  m=summary['measurements'][label]
  assert abs(delta-m['maximum_evidence_difference_bits'])<1e-15
  assert abs(delta/915860-m['maximum_codelength_difference_bits_per_token'])<1e-20
  assert abs(abs(mixed(x)-mixed(y))/(915860*math.log(2))-m['mixture_codelength_difference_bits_per_token'])<1e-14
  assert max(m[k] for k in ('maximum_codelength_difference_bits_per_token','mixture_codelength_difference_bits_per_token'))<=1e-5
 reconstructed_grid=[]
 for depth,a,b in zip(depths,assembled['default']['diagnostics']['components'],assembled['supplement']['diagnostics']['components'],strict=True):
  x,y=a.get('outer_grid_step'),b.get('outer_grid_step')
  if depth<=1:
   assert x is None and y is None
   status='analytic'
  else:
   assert all(isinstance(v,(int,float)) and math.isfinite(v) and v>0 for v in (x,y))
   assert y<=.51*x
   status='halved'
  reconstructed_grid.append({'depth':depth,'default_step':x,'final_step':y,'status':status})
 assert reconstructed_grid==summary['grid_assessment']
 assert sorted(r['depth'] for r in summary['depth_records'])==depths
 assert all(r['status']=='evaluated' for r in summary['depth_records'])
 for depth,record in zip(depths,summary['depth_records'],strict=True):
  assert record==read(RUN/'checkpoints'/f'depth-{depth:02d}-status.json')
  assert record['has_supplement']==(RUN/'checkpoints'/f'depth-{depth:02d}-supplement.json').exists()
 prior=read(RUN/'output-manifest.json');mismatches=[]
 for r in prior:
  if sha(RUN/r['path'])!=r['sha256']:mismatches.append(r['path'])
 assert mismatches==['stdout.log'],mismatches
 result={'status':'passed','verified_at_utc':datetime.now(timezone.utc).isoformat(),'posterior_consistency_checks':posterior_checks,'posterior_roundoff_note':'The original exp(logs-logsumexp(logs)) weights can share a normalization-rounding error at the large absolute log-evidence scale. Absolute discrepancy allows four log-evidence ulps; independently normalized relative weights retain the strict 2e-12 tolerance. Scientific codelength gates are unchanged.','checks':['all 55 declared depths and per-depth checkpoint assembly','saved input and complete frozen scientific source hashes','checkpoint engine identities and exact permitted supplemental settings','default/refined/supplemented evidence and diagnostics preserved','equal-prior full-grid mixture and posterior recalculation','analytic depth-zero and depth-one evidence','all measured actual-grid halvings','all component and mixture codelength gates'],'driver_output_manifest_note':'The driver recorded stdout before its final print. Only stdout.log differs from that provisional manifest. The final closed-process manifest supersedes that stdout entry.','original_manifest_mismatches':mismatches}
 with (RUN/'independent-verification.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True)
 manifest={'timing':'after all worker and driver processes completed','supersedes_provisional_stdout_hash':True,'files':{str(p.relative_to(RUN)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(RUN.rglob('*')) if p.is_file()}}
 with (RUN/'final-manifest.json').open('x') as f:json.dump(manifest,f,indent=2,sort_keys=True)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
