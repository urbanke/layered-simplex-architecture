"""Read-only scientific-source probe; outputs belong to this separate diagnosis."""
import argparse
import hashlib
import json
import math
import os
import pathlib
import platform
import sys
import numpy as np
import scipy
from scipy.optimize import brentq
from scipy.special import roots_legendre
from lsa.alt.powers import PowerSettings, log_scaled_kernel, _expm1_minus_x

CASES = [(0,59,0.02737464341427795), (0,80,0.09115050933976537),
         (0,60,0.031201174682110977), (0,77,0.08495046975937914),
         (1,80,0.09115050933976537)]
NODES = [32,64,128,256,512]

def geometry(r,w,v):
    a=w*r+1.; log_a=math.log(a)
    hi=min(log_a,v+(log_a-math.log(w))/w)
    mode=brentq(lambda s:np.logaddexp(s,math.log(w)+w*(s-v))-log_a,
                hi-math.log(2)-1e-12,hi+1e-12,xtol=1e-14,rtol=1e-14)
    p=math.exp(mode); log_q=w*(mode-v); q=math.exp(log_q)
    def drop(z):return -p*_expm1_minus_x(z)-q*_expm1_minus_x(w*z)
    scale=1/math.sqrt(p+w*w*q); bounds=[]
    for direction in [-1,1]:
        far=direction*scale
        while float(drop(far))>=-48:far*=2
        lo,hi=sorted([0.,far])
        bounds.append(brentq(lambda z:float(drop(z))+48,lo,hi,xtol=1e-13))
    left,right=bounds; splits=[left,0.,right]
    if r==0:splits += [v-mode+offset/w for offset in [-4,0,4] if left<v-mode+offset/w<right]
    splits=np.array(sorted(set(splits))); mids=(splits[1:]+splits[:-1])/2; halves=np.diff(splits)/2
    return dict(mode=mode,p=p,q=q,log_q=log_q,splits=splits.tolist()),drop,mids,halves

def evaluate(r,w,v,rule):
    g,drop,mids,halves=geometry(r,w,v)
    rows=[]
    for n in NODES:
        x,weights=rule(n);z=mids[:,None]+halves[:,None]*x
        pieces=(np.exp(drop(z))@weights)*halves
        value=float(np.sum(pieces));logi=math.log(value)
        rows.append(dict(nodes=n,log_integral=logi,log_value=g['mode']+r*g['log_q']-g['p']-g['q']+logi,pieces=pieces.tolist()))
    return dict(r=r,w=w,v=v,geometry=g,rows=rows)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);parser.add_argument('--rules')
    args=parser.parse_args();out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=False)
    rules={}; summary=dict(python=sys.version,platform=platform.platform(),host=platform.node(),
        numpy=np.__version__,scipy=scipy.__version__,slurm_job=os.environ.get('SLURM_JOB_ID'),
        source_sha256=hashlib.sha256(pathlib.Path(sys.modules['lsa.alt.powers'].__file__).read_bytes()).hexdigest(),
        probe_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),families={})
    factories={'scipy':roots_legendre,'numpy':np.polynomial.legendre.leggauss}
    if args.rules:
        high=np.load(args.rules);factories['mp80_rounded']=lambda n:(high[f'x_{n}'],high[f'w_{n}'])
    for label,factory in factories.items():
        saved={n:factory(n) for n in NODES}
        for n,(x,weights) in saved.items():rules[f'{label}_x_{n}']=x;rules[f'{label}_w_{n}']=weights
        rows=[evaluate(*case,lambda n:saved[n]) for case in CASES]
        summary['families'][label]=rows
    summary['production']=[]
    for r,w,v in CASES:
        try:row=dict(value=log_scaled_kernel(r,w,v,settings=PowerSettings(kernel_log_tolerance=5e-13,kernel_tail_drop=48)))
        except Exception as exc:row=dict(error=str(exc))
        summary['production'].append(dict(r=r,w=w,v=v,**row))
    (out/'probe.json').write_text(json.dumps(summary,indent=2)+'\n');np.savez(out/'rules.npz',**rules)
    print(json.dumps(dict(out=str(out),production=summary['production'])),flush=True)

if __name__=='__main__':main()
