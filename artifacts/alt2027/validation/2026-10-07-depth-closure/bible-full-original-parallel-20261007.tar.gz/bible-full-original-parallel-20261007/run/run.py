"""Complete the interrupted saved Bible case, with immutable depth checkpoints.

The engine is the frozen original checkout, not the later adaptive-window fix.
Each depth has independent default/refined/supplemental checkpoints. Assembly
restores the exact declared ordering and computes the full equal-prior mixture.
"""
from __future__ import annotations
import copy, gzip, hashlib, importlib.metadata, json, math, os, platform
import shutil, subprocess, sys, time, traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from scipy.special import logsumexp
from lsa.alt.artifacts import canonical_hash, sha256, write_json
from lsa.alt.benchmark import jsonable
from lsa.alt.depth import DepthEvaluator, StoreConfig
from lsa.alt.depth_validation import comparison

MAIN=Path('/Users/ruediger/Documents/Codex/2026-10-06/i-ha/work/github-cleanup')
SOURCE=MAIN.parent/'alt-pilot-d1e4d26'
ORIGINAL=MAIN/'output/alt2027/depth-calibration-20261007/shard-2'
OUT=Path(__file__).resolve().parent
WORKERS=7
STATE={}

def write_new(path,obj):
    with Path(path).open('x') as f: json.dump(jsonable(obj),f,indent=2,sort_keys=True,allow_nan=False)

def load(path): return json.loads(Path(path).read_text())

def unchanged(manifest):
    return all(sha256(Path(p))==v for p,v in manifest.items())

def init_worker():
    inp=OUT/'inputs'; config=load(inp/'config.json'); case=config['cases'][6]
    with np.load(inp/'case-006.npz',allow_pickle=False) as z:
        counts=z['counts']; target=z['target']
    assert counts.shape==(case['d'],) and int(counts.sum())==case['n']
    assert np.all(counts>=0) and np.all(target>=0) and np.isclose(target.sum(),1)
    supplied=load(inp/'engine-candidate.json')
    evaluators={}
    for label in ('default','refined'):
        saved=load(inp/f'{label}-engine.json')
        settings=dict(saved['store'],path=supplied['store']['path'])
        evaluator=DepthEvaluator(mode='store',store=StoreConfig(**settings),prediction_tolerance=config['raw_mass_tolerance'])
        if evaluator.configuration!=saved: raise RuntimeError(f'{label} engine identity mismatch')
        evaluators[label]=evaluator
    STATE.update(config=config,case=case,profile=tuple(counts[counts>0]),evaluators=evaluators,source_hashes=load(OUT/'source-hashes.json'))

def evaluate_depth(depth):
    started=time.monotonic(); s=STATE; case=s['case']; results={}; supplements={}
    print(f'START depth={depth} pid={os.getpid()}',flush=True)
    try:
        if not unchanged(s['source_hashes']): raise RuntimeError('source changed before evaluation')
        for label,evaluator in s['evaluators'].items():
            phase=time.monotonic()
            result=jsonable(evaluator.evidence_at_depths(case['d'],s['profile'],[depth]))
            write_new(OUT/'checkpoints'/f'depth-{depth:02d}-{label}.json',dict(result=result,seconds=time.monotonic()-phase,engine_sha256=evaluator.configuration_sha256))
            results[label]=result
            print(f'PHASE depth={depth} label={label} seconds={time.monotonic()-phase:.3f}',flush=True)
        a=results['default']['diagnostics']['components'][0]
        b=results['refined']['diagnostics']['components'][0]
        x,y=a.get('outer_grid_step'),b.get('outer_grid_step')
        if x is not None and y>0.51*x:
            settings=dict(s['evaluators']['refined'].configuration['store'],path=s['evaluators']['refined'].store_config.path)
            step=min(x,y)/2
            settings['grid_step']=step
            settings['minimum_grid_step']=min(settings['minimum_grid_step'],step)
            phase=time.monotonic()
            with DepthEvaluator(mode='store',store=StoreConfig(**settings),prediction_tolerance=s['config']['raw_mass_tolerance']) as evaluator:
                value=jsonable(evaluator.evidence_at_depths(case['d'],s['profile'],[depth]))
                write_new(OUT/'checkpoints'/f'depth-{depth:02d}-supplement.json',dict(result=value,seconds=time.monotonic()-phase,engine=evaluator.configuration,engine_sha256=evaluator.configuration_sha256))
                supplements[depth]=value
            print(f'PHASE depth={depth} label=supplement seconds={time.monotonic()-phase:.3f}',flush=True)
        if not unchanged(s['source_hashes']): raise RuntimeError('source changed during evaluation')
        record={'depth':depth,'status':'evaluated','seconds':time.monotonic()-started,'has_supplement':bool(supplements)}
    except Exception as exc:
        record={'depth':depth,'status':'failed','seconds':time.monotonic()-started,'error':{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}}
    write_new(OUT/'checkpoints'/f'depth-{depth:02d}-status.json',record)
    print(f'DONE {json.dumps(record)}',flush=True)
    return record

def assemble(label,depths):
    rows=[]
    for depth in depths:
        p=OUT/'checkpoints'/f'depth-{depth:02d}-{label}.json'
        if label=='supplement' and not p.exists(): p=OUT/'checkpoints'/f'depth-{depth:02d}-refined.json'
        rows.append(load(p)['result'])
    value=copy.deepcopy(rows[0]); value['depths']=depths
    value['log_evidence']=[row['log_evidence'][0] for row in rows]
    value['diagnostics']['components']=[row['diagnostics']['components'][0] for row in rows]
    if label=='supplement':
        value['diagnostics'].pop('configuration_sha256',None)
        value['diagnostics']['configuration_note']='Derived mixture: refined per-depth results replaced only by checkpointed actual-grid halvings.'
    return value

def main():
    started=time.monotonic(); (OUT/'inputs').mkdir(); (OUT/'checkpoints').mkdir()
    sources={str(p):sha256(p) for p in sorted((SOURCE/'src').rglob('*')) if p.is_file() and p.suffix in ('.py','.json')}
    write_new(OUT/'source-hashes.json',sources)
    input_records=[]
    for name in ('config.json','implementation.json','default-engine.json','refined-engine.json','case-006.npz','corpus-6.json'):
        p=ORIGINAL/name; shutil.copyfile(p,OUT/'inputs'/name)
        input_records.append({'source':str(p),'snapshot':'inputs/'+name,'sha256':sha256(p)})
    for p in (MAIN/'output/alt2027/engine-candidate.json',SOURCE/'requirements-alt.lock',MAIN/'experiments/alt2027/depth-validation.json'):
        name='declared-depth-validation.json' if p.name=='depth-validation.json' else p.name
        shutil.copyfile(p,OUT/'inputs'/name)
        input_records.append({'source':str(p),'snapshot':'inputs/'+name,'sha256':sha256(p)})
    for absolute in sources:
        p=Path(absolute); dest=OUT/'source-capsule'/p.relative_to(SOURCE)
        dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dest)
    write_new(OUT/'input-manifest.json',input_records)
    config=load(OUT/'inputs/config.json'); case=config['cases'][6]
    original_hashes=load(OUT/'inputs/implementation.json')
    for name,digest in original_hashes.items(): assert sha256(SOURCE/'src/lsa/alt'/name)==digest
    assert case['id']=='bible-915860' and case['depths']==list(range(55))
    versions={p.metadata['Name']:p.version for p in importlib.metadata.distributions()}
    manifest={'purpose':'validation','status':'running','original_case':case,'sample_sha256':sha256(OUT/'inputs/case-006.npz'),'source_commit':subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),'source_hash_manifest_sha256':sha256(OUT/'source-hashes.json'),'driver_sha256':sha256(__file__),'workers':WORKERS,'parallelization':'independent depths; same saved profile and original engine; no random draws','execution':{'python':sys.executable,'pythonpath':os.environ.get('PYTHONPATH'),'argv':sys.argv,'cwd':os.getcwd(),'threads':{k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS')},'platform':platform.platform(),'packages':versions}}
    write_new(OUT/'request.json',manifest)
    # Start the expensive high-depth direct route early; assembly retains declaration order.
    order=sorted(case['depths'],reverse=True)
    records=[]
    with ProcessPoolExecutor(max_workers=WORKERS,initializer=init_worker) as pool:
        futures={pool.submit(evaluate_depth,d):d for d in order}
        for f in as_completed(futures): records.append(f.result())
    records.sort(key=lambda r:r['depth'])
    summary={'status':'failed','case':case,'depth_records':records,'seconds':time.monotonic()-started,'source_unchanged':unchanged(sources),'sample_sha256':manifest['sample_sha256'],'scope':'All 55 declared depths, original frozen implementation, default/refined and actual-grid-halving supplements. Finite saved-case validation only; no production acceptance.'}
    if all(r['status']=='evaluated' for r in records):
        assembled={label:assemble(label,case['depths']) for label in ('default','refined','supplement')}
        for label,value in assembled.items():
            logs=np.asarray(value['log_evidence'])
            write_new(OUT/f'{label}-posterior.json',{'depths':case['depths'],'posterior':np.exp(logs-logsumexp(logs)).tolist(),'mixture_log_evidence_nats':float(logsumexp(logs)-math.log(len(logs)))})
        with gzip.open(OUT/'evaluation-006.json.gz','xt') as f: json.dump({k:assembled[k] for k in ('default','refined')},f,allow_nan=False)
        with gzip.open(OUT/'evaluation-supplemented.json.gz','xt') as f: json.dump(assembled,f,allow_nan=False)
        measures={}
        for label,a,b in [('original','default','refined'),('supplemental','refined','supplement'),('final','default','supplement')]:
            measures[label]=comparison(SimpleNamespace(log_evidence=np.asarray(assembled[a]['log_evidence'])),SimpleNamespace(log_evidence=np.asarray(assembled[b]['log_evidence'])),n=case['n'])
        grid=[]
        for depth,a,b in zip(case['depths'],assembled['default']['diagnostics']['components'],assembled['supplement']['diagnostics']['components']):
            x,y=a.get('outer_grid_step'),b.get('outer_grid_step')
            grid.append({'depth':depth,'default_step':x,'final_step':y,'status':'analytic' if x is None and depth<=1 else ('halved' if y<=.51*x else 'pending')})
        passed=summary['source_unchanged'] and all(m[k]<=config['loss_tolerance_bits'] for m in measures.values() for k in ('maximum_codelength_difference_bits_per_token','mixture_codelength_difference_bits_per_token')) and all(g['status']!='pending' for g in grid)
        summary.update(status='passed' if passed else 'failed',measurements=measures,grid_assessment=grid)
        write_new(OUT/'result-006.json',{'id':case['id'],'case':case,'sample_sha256':manifest['sample_sha256'],'status':'passed' if all(measures['original'][k]<=config['loss_tolerance_bits'] for k in ('maximum_codelength_difference_bits_per_token','mixture_codelength_difference_bits_per_token')) else 'failed','measurements':measures['original'],'seconds':time.monotonic()-started,'execution_note':'Per-depth checkpoints assembled in declared order; original source and identical engine configurations.'})
    write_new(OUT/'summary.json',summary)
    write_new(OUT/'output-manifest.json',[{'path':str(p.relative_to(OUT)),'sha256':sha256(p),'bytes':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file()])
    print(json.dumps({k:v for k,v in summary.items() if k not in ('depth_records','grid_assessment','case')},indent=2),flush=True)

if __name__=='__main__': main()
