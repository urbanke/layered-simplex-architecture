from pathlib import Path
import json,time
from lsa.alt.depth_validation_assessment import assess_depth_run
source=Path('output/alt2027/adaptive-window-repaired-cases-20261007')
assert (source/'summary.json').is_file(), 'Both original cases must be complete before assessment'
assert json.loads((source/'summary.json').read_text())['status']=='passed'
summary=assess_depth_run(source,'output/alt2027/adaptive-window-repaired-assessment-20261007',engine_config=json.loads(Path('output/alt2027/engine-candidate.json').read_text()),run_supplemental=True,config_path=source/'config.json')
print(json.dumps(summary,indent=2),flush=True)
