"""Independent high-precision rules and E-coordinate reference kernels."""
import json
import pathlib
import time
import mpmath as mp
import numpy as np
from probe import CASES,NODES

root=pathlib.Path(__file__).resolve().parent
mp.mp.dps=80
rules={};report={'dps':80,'rules':{},'kernels':[]}
for n in NODES:
    start=time.perf_counter();xs=[];ws=[]
    for i in range(1,n//2+1):
        x=mp.cos(mp.pi*(i-mp.mpf('.25'))/(n+mp.mpf('.5')))
        for _ in range(12):
            p0=mp.mpf(1);p1=x
            for k in range(2,n+1):p0,p1=p1,((2*k-1)*x*p1-(k-1)*p0)/k
            dp=n*(p0-x*p1)/(1-x*x);change=p1/dp;x-=change
            if abs(change)<mp.mpf('1e-75'):break
        else:raise RuntimeError('Newton failed')
        p0=mp.mpf(1);p1=x
        for k in range(2,n+1):p0,p1=p1,((2*k-1)*x*p1-(k-1)*p0)/k
        dp=n*(p0-x*p1)/(1-x*x);weight=2/((1-x*x)*dp*dp)
        xs += [-x,x];ws += [weight,weight]
    order=sorted(range(n),key=xs.__getitem__);xs=[xs[i] for i in order];ws=[ws[i] for i in order]
    rules[f'x_{n}']=np.array(xs,dtype=float);rules[f'w_{n}']=np.array(ws,dtype=float)
    report['rules'][n]={'sum_error':str(sum(ws)-2),'max_test_moment_error':str(max(abs(sum(weight*x**k for x,weight in zip(xs,ws))-mp.mpf(2)/(k+1)) for k in [2,4,20,100] if k<2*n)), 'seconds':time.perf_counter()-start}
    print(n,report['rules'][n],flush=True)
np.savez(root/'mp80-rules.npz',**rules)
for r,w,v0 in CASES:
    values=[]
    for digits in [60,80]:
        with mp.workdps(digits):
            v=mp.mpf(v0);b=mp.exp(v);t=mp.exp(-w*v)
            # E coordinates: t^r E^(w*r) exp(-E-t E^w). For these selected
            # cases the tail beyond 2*b is exponentially below 1e-1000.
            value=mp.quad(lambda x:(t*x**w)**r*mp.exp(-x-t*x**w),[0,b/2,b*mp.mpf('.9'),b,b*mp.mpf('1.1'),b*mp.mpf('1.5'),2*b])
            values.append(mp.log(value))
    row={'r':r,'w':w,'v':v0,'log_value':str(values[-1]),'precision_change':str(abs(values[1]-values[0]))}
    report['kernels'].append(row);print(row,flush=True)
(root/'mp80-reference.json').write_text(json.dumps(report,indent=2)+'\n')
