import json
from pathlib import Path
from lsa.alt.depth_validation_assessment import assess_depth_run
out = Path('output/alt2027/depth-assessment-final-original-20261007')
summary = assess_depth_run('output/alt2027/depth-calibration-20261007', out, engine_config=json.loads(Path('output/alt2027/engine-candidate.json').read_text()), run_supplemental=True, config_path='experiments/alt2027/depth-validation.json')
print(json.dumps({k: summary[k] for k in ('status','expected_cases','completed_cases_read','pending_case_ids','source_unchanged')}, indent=2), flush=True)
print(json.dumps([{'id': x['id'], 'status': x['status'], 'reason': x.get('reason'), 'acceptance': x.get('acceptance'), 'supplemental_acceptance':x.get('supplemental_acceptance')} for x in summary['cases']], indent=2), flush=True)
