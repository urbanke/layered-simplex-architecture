"""Finite, held-out checks of the sealed reader against corrected direct kernels.

This is a reader/interpolation and float64 refinement check, not an independent
high-precision reference or a production admission certificate. Absolute gates
are never increased to accommodate floating-point precision limitations.
"""

from __future__ import annotations

import argparse
import json
import math
import platform
import shutil
import time
from collections import defaultdict
from itertools import pairwise
from pathlib import Path

import numpy as np
import scipy

from .artifacts import Run, canonical_hash, read_json, sha256, verify_run, write_json

NOMINAL_TOLERANCE_NATS = 3e-9
LOW_COUNT_TOLERANCE_NATS = 1e-11
PILOT_DEPTHS = (2, 22, 53, 54, 80, 138)
PILOT_COUNTS = (0, 1, 2, 3, 255, 256, 257, 1000, 20000, 1000000, 1045889)


def validation_config():
    """Return the fixed pilot selection; resolution is saved before evaluation."""
    return {
        "depths": list(PILOT_DEPTHS),
        "counts": list(PILOT_COUNTS),
        "u_values": [
            -4.013,
            -0.2573,
            5.213,
            10.007,
            35.0,
            35.013,
            59.987,
            79.993,
            80.0,
        ],
        "shifted_u_offsets": [-4.013, 0.007, 6.013],
        "all_low_count_depths": True,
        "anchor_gap_cases": True,
        "join_cases": True,
    }


def _integer(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def resolve_validation_cases(table, config):
    """Resolve a deterministic case grid from coverage, never from result values.

    Explicit ``cases`` may instead replay an already declared finite grid.
    Uncovered pilot strata are reported, not silently counted as successful.
    """
    cases, unavailable = {}, []
    levels = tuple(table.coverage_depths)
    support = table.supported_count

    def add(L, r, u, group):
        L, r = _integer(L, "depth", 1), _integer(r, "count")
        u = float(u)
        if (
            L not in levels
            or r > support
            or not math.isfinite(u)
            or u > table.maximum_u
        ):
            raise ValueError(f"validation case outside sealed coverage: {(L, r, u)}")
        key = L, r, u
        item = cases.setdefault(key, {"depth": L, "r": r, "u": u, "groups": []})
        if group not in item["groups"]:
            item["groups"].append(group)

    if "cases" in config:
        if not config["cases"]:
            raise ValueError("validation requires nonempty cases")
        for case in config["cases"]:
            add(case["depth"], case["r"], case["u"], "explicit-declared-grid")
    else:
        for L in config["depths"]:
            _integer(L, "depth", 1)
            if L not in levels:
                unavailable.append({"depth": L, "reason": "pilot level outside store"})
                continue
            counts = set()
            for r in config["counts"]:
                _integer(r, "count")
                if r <= support:
                    counts.add(r)
                else:
                    unavailable.append(
                        {"depth": L, "r": r, "reason": "count outside store"}
                    )
            anchors = tuple(int(r) for r in table.count_anchors(L))
            if config.get("anchor_gap_cases", True):
                gaps = [
                    (a, b)
                    for a, b in pairwise(anchors)
                    if b - a > 1 and a < support
                ]
                if gaps:
                    chosen = {
                        gaps[0],
                        gaps[len(gaps) // 2],
                        gaps[-1],
                        max(gaps, key=lambda ab: ab[1] - ab[0]),
                    }
                    for a, b in sorted(chosen):
                        for r in (a + 1, int(math.sqrt((a + 1) * (b + 1)) - 1), b - 1):
                            if a < r < b and r <= support:
                                counts.add(r)
            for r in sorted(counts):
                label = (
                    "declared-count" if r in config["counts"] else "held-out-anchor-gap"
                )
                for u in config["u_values"]:
                    if u <= table.maximum_u:
                        add(L, r, u, label)
                    else:
                        unavailable.append(
                            {"depth": L, "r": r, "u": u, "reason": "u outside store"}
                        )
                for offset in config["shifted_u_offsets"]:
                    add(L, r, -L * math.log(r + 1) + offset, "shifted-off-grid")
                if config.get("join_cases", True):
                    join = -float(table.plan["left_drop"]) - L * math.log(r + 1)
                    for step in (-0.37, 0.0, 0.37, 1.13):
                        add(L, r, join + step * table.grid_step, "analytic-left-join")
                    # Test physical column endpoints independently of the tail join.
                    # At a held-out count, include both neighboring anchor edges.
                    j = int(np.searchsorted(anchors, r))
                    near = {anchors[min(j, len(anchors) - 1)], anchors[max(0, j - 1)]}
                    for a in sorted(near):
                        edge = float(table.column_metadata(L, a)["u_min"])
                        for step in (-0.37, 0.0, 0.37):
                            add(L, r, edge + step * table.grid_step, "stored-left-edge")
        if config.get("all_low_count_depths", True):
            # Every covered level appears, with each low count, at one shifted
            # point and one stratified right-window point. No random draws.
            right_points = (35.013, 59.987, 79.993)
            for i, L in enumerate(levels):
                for r in range(min(3, support) + 1):
                    add(L, r, -L * math.log(r + 1) - 4.013, "all-level-low-count")
                    u = right_points[(i + r) % len(right_points)]
                    if u <= table.maximum_u:
                        add(L, r, u, "all-level-low-count-right-window")
    if not cases:
        raise ValueError("no validation cases fall inside the sealed store")
    ordered = sorted(cases.values(), key=lambda x: (x["depth"], x["r"], x["u"]))
    return [
        dict(c, case_id=f"sealed-{i:05d}") for i, c in enumerate(ordered)
    ], unavailable


def assess_measurement(r, scalar, matrix, reference, refined):
    """Apply unchanged absolute gates and expose unresolved reference precision."""
    values = [float(x) for x in (scalar, matrix, reference, refined)]
    if not all(math.isfinite(x) for x in values):
        raise ArithmeticError("reader and reference values must all be finite")
    scalar, matrix, reference, refined = values
    tolerance = LOW_COUNT_TOLERANCE_NATS if r <= 3 else NOMINAL_TOLERANCE_NATS
    scalar_error, matrix_error = scalar - refined, matrix - refined
    refinement_delta, path_delta = reference - refined, scalar - matrix
    ulp = max(abs(float(np.spacing(v))) for v in (reference, refined))
    error_passed = max(abs(scalar_error), abs(matrix_error)) <= tolerance
    reference_converged = abs(refinement_delta) <= tolerance
    path_passed = abs(path_delta) <= tolerance
    precision_limited = ulp > tolerance
    passed = (
        error_passed and reference_converged and path_passed and not precision_limited
    )
    return {
        "status": "passed"
        if passed
        else "precision_limited"
        if precision_limited
        else "failed",
        "scalar_log_phi_nats": scalar,
        "matrix_log_phi_nats": matrix,
        "direct_reference_log_phi_nats": reference,
        "refined_reference_log_phi_nats": refined,
        "scalar_error_nats": scalar_error,
        "matrix_error_nats": matrix_error,
        "scalar_matrix_delta_nats": path_delta,
        "scalar_matrix_bitwise_equal": bool(
            np.float64(scalar).tobytes() == np.float64(matrix).tobytes()
        ),
        "reference_refinement_delta_nats": refinement_delta,
        "reference_float64_ulp_nats": ulp,
        "precision_floor_exceeds_gate": precision_limited,
        "tolerance_nats": tolerance,
        "within_nominal_tolerance": error_passed,
        "reference_refinement_passed": reference_converged,
        "scalar_matrix_passed": path_passed,
    }


def _implementation_identity():
    base = Path(__file__).parent
    sources = [
        Path(__file__),
        base / "sealed_tables.py",
        base / "sealed_store_build.py",
        *sorted((base / "_vendor/pmwm").glob("*.py")),
    ]
    return {
        "source_sha256": {str(p): sha256(p) for p in sources if p.is_file()},
        "runtime": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
        },
    }


def _store_files(path, manifest):
    # The reader verifies its sealed manifest before this helper is reached.
    return {
        name: sha256(path / name)
        for name in sorted({"plan.json", "manifest.json", *manifest["files"]})
    }


def _direct_reference(r, L, u, *, refined):
    from ._vendor.pmwm import _runtime
    from ._vendor.pmwm.mellin import exact_log_phi_column

    token = _runtime._settings.set({"PMM_BUILD_EXACT": "1"})
    try:
        return exact_log_phi_column(
            r,
            L,
            u,
            oversample=16.0 if refined else 8.0,
            series_tolerance=1e-14 if refined else 1e-13,
            contour_tail_nats=50.0 if refined else 40.0,
        )
    finally:
        _runtime._settings.reset(token)


def _execute_validation(table, outdir, config):
    path, root = table.path, Path(outdir)
    try:
        cases, unavailable = resolve_validation_cases(table, config)
        initial_store = dict(table.files_identity)
        identity = _implementation_identity()
        root.mkdir(parents=True, exist_ok=False)
        write_json(root / "config.json", config)
        write_json(root / "resolved-cases.json", cases)
        write_json(root / "unavailable-strata.json", unavailable)
        write_json(root / "implementation.json", identity)
        write_json(
            root / "store-inputs.json", {"path": str(path), "sha256": initial_store}
        )
        levels = defaultdict(list)
        for case in cases:
            levels[case["depth"]].append(case)
        rows = []
        with (root / "rows.jsonl").open("x") as stream:
            for L, group in levels.items():
                started = time.monotonic()
                rs, us = (
                    sorted({c["r"] for c in group}),
                    sorted({c["u"] for c in group}),
                )
                r_index, u_index = (
                    {r: i for i, r in enumerate(rs)},
                    {u: i for i, u in enumerate(us)},
                )
                matrix_error = None
                try:
                    matrix = np.asarray(table.log_phi_matrix(L, rs, us))
                    if matrix.shape != (len(rs), len(us)):
                        raise ValueError("reader returned incorrect matrix shape")
                except (ArithmeticError, RuntimeError, ValueError) as exc:
                    matrix_error = f"{type(exc).__name__}: {exc}"
                by_count = defaultdict(list)
                for case in group:
                    by_count[case["r"]].append(case)
                for r, count_cases in by_count.items():
                    query = np.array([c["u"] for c in count_cases])
                    failure = None
                    try:
                        direct = np.asarray(
                            _direct_reference(r, L, query, refined=False)
                        )
                        refined = np.asarray(
                            _direct_reference(r, L, query, refined=True)
                        )
                        if direct.shape != query.shape or refined.shape != query.shape:
                            raise ValueError(
                                "reference returned incorrect column shape"
                            )
                    except (ArithmeticError, RuntimeError, ValueError) as exc:
                        failure = f"{type(exc).__name__}: {exc}"
                    for i, case in enumerate(count_cases):
                        row = dict(case)
                        try:
                            if matrix_error or failure:
                                raise ArithmeticError(matrix_error or failure)
                            # A one-point scalar query exercises a genuinely
                            # different call shape from the shared matrix grid.
                            scalar = np.asarray(table.log_phi(L, r, [case["u"]]))
                            if scalar.shape != (1,):
                                raise ValueError(
                                    "reader returned incorrect scalar shape"
                                )
                            row.update(
                                assess_measurement(
                                    r,
                                    scalar[0],
                                    matrix[r_index[r], u_index[case["u"]]],
                                    direct[i],
                                    refined[i],
                                )
                            )
                        except (ArithmeticError, RuntimeError, ValueError) as exc:
                            row.update(
                                status="failed",
                                error={"type": type(exc).__name__, "message": str(exc)},
                            )
                        stream.write(json.dumps(row, allow_nan=False) + "\n")
                        rows.append(row)
                stream.flush()
                print(
                    f"sealed reader L={L}: {len(group)} cases, {time.monotonic() - started:.2f}s",
                    flush=True,
                )
        final_store = _store_files(path, table.manifest)
        unchanged_store = initial_store == final_store
        unchanged_source = identity == _implementation_identity()
        measured = [r for r in rows if "scalar_error_nats" in r]
        passed = all(r["status"] == "passed" for r in rows)
        summary = {
            "status": "passed"
            if passed and unchanged_store and unchanged_source
            else "failed",
            "scope": "declared finite reader/interpolation cases and direct float64 refinement; not a uniform kernel bound",
            "production_certified": False,
            "independent_high_precision_reference": False,
            "config_sha256": canonical_hash(config),
            "resolved_cases_sha256": canonical_hash(cases),
            "cases": len(rows),
            "passed_cases": sum(r["status"] == "passed" for r in rows),
            "failed_cases": sum(r["status"] == "failed" for r in rows),
            "precision_limited_cases": sum(
                r["status"] == "precision_limited" for r in rows
            ),
            "levels": sorted(levels),
            "unavailable_strata": unavailable,
            "maximum_absolute_error_nats": max(
                (
                    max(abs(r["scalar_error_nats"]), abs(r["matrix_error_nats"]))
                    for r in measured
                ),
                default=None,
            ),
            "maximum_low_count_error_nats": max(
                (
                    max(abs(r["scalar_error_nats"]), abs(r["matrix_error_nats"]))
                    for r in measured
                    if r["r"] <= 3
                ),
                default=None,
            ),
            "maximum_scalar_matrix_delta_nats": max(
                (abs(r["scalar_matrix_delta_nats"]) for r in measured), default=None
            ),
            "store_unchanged": unchanged_store,
            "source_unchanged": unchanged_source,
            "gates_nats": {
                "general": NOMINAL_TOLERANCE_NATS,
                "counts_0_to_3": LOW_COUNT_TOLERANCE_NATS,
            },
            "reference": {
                "method": "corrected exact_log_phi_column",
                "relationship_to_builder": "same numerical implementation as the offline builder, queried at held-out points and refined; not an independent algorithm",
                "oversample": [8, 16],
                "series_tolerance": [1e-13, 1e-14],
                "contour_tail_nats": [40, 50],
                "precision_policy": "float64 ULP above the unchanged nominal gate is unresolved, never a relaxed pass",
            },
            "required_followup": "independent high-precision rows; sealed versus direct profile/augmentation/mixture comparisons; outer refinement and raw normalization; existing full-domain depth and chain suites; source/runtime/store-bound admission",
        }
        write_json(root / "summary.json", summary)
        outputs = {p.name: sha256(p) for p in root.iterdir() if p.is_file()}
        write_json(root / "output-manifest.json", outputs)
        return summary
    finally:
        table.close()


def run_sealed_store_validation(
    store,
    outdir,
    *,
    config=None,
    repo=None,
    engine_config=None,
    config_path=None,
    engine_path=None,
):
    """Save a normal immutable validation Run; a failed gate raises after saving.

    A store-only run binds the complete sealed file inventory. With an engine
    configuration, additionally bind the actual depth evaluator configuration,
    including settings, source and runtime, without evaluating any profiles.
    """
    from .sealed_tables import SealedKernelTables

    config = validation_config() if config is None else config
    repo = Path(repo) if repo is not None else Path(__file__).resolve().parents[3]
    path, root = Path(store).resolve(strict=True), Path(outdir).resolve()
    if root == path or path in root.parents:
        raise ValueError("validation output must be outside the immutable store")
    table = SealedKernelTables(path)
    try:
        # Resolve before opening the Run so malformed declarations cannot create
        # an apparently useful partial calibration record.
        resolve_validation_cases(table, config)
        if engine_config is not None:
            from .depth import DepthEvaluator, StoreConfig

            if (
                engine_config.get("mode") != "store"
                or engine_config["store"].get("format") != "sealed"
            ):
                raise ValueError("engine configuration must select a sealed store")
            if Path(engine_config["store"]["path"]).resolve() != path:
                raise ValueError("engine configuration points to a different store")
            if engine_config["store"].get("files_sha256") != dict(table.files_identity):
                raise ValueError(
                    "engine must bind the complete sealed-store hash mapping"
                )
            with DepthEvaluator(
                mode="store",
                store=StoreConfig(**engine_config["store"]),
                prediction_tolerance=engine_config.get("prediction_tolerance", 1e-3),
            ) as evaluator:
                engine_identity = evaluator.configuration
        else:
            engine_identity = {
                "provider": "sealed-kernel-reader",
                "store": {
                    "format": "sealed",
                    "files_sha256": dict(table.files_identity),
                    "plan_sha256": table.plan_sha256,
                },
                "implementation": _implementation_identity(),
            }
        inputs = [path / "plan.json", path / "manifest.json"]
        inputs += [Path(p) for p in (config_path, engine_path) if p is not None]
        with Run(
            root,
            repo=repo,
            protocol={"suite": "sealed_store", "config": config},
            experiment="calibration_sealed_store",
            purpose="validation",
            engine_identity=engine_identity,
            inputs=inputs,
        ) as run:
            capsule = run.path / "source-capsule"
            for name in run.record["source"]["files"]:
                if name.startswith(("src/", "scripts/")) or name in (
                    "pyproject.toml",
                    "requirements-alt.lock",
                ):
                    target = capsule / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(repo / name, target)
            write_json(run.path / "store-plan.json", read_json(path / "plan.json"))
            write_json(
                run.path / "store-manifest.json", read_json(path / "manifest.json")
            )
            if engine_config is not None:
                write_json(run.path / "engine-options.json", engine_config)
            result = _execute_validation(table, run.path / "data", config)
            result["engine_sha256"] = canonical_hash(engine_identity)
            result["store_files_sha256"] = dict(table.files_identity)
            write_json(run.path / "result.json", result)
            if result["status"] != "passed":
                raise ArithmeticError(
                    "sealed-store calibration has failed or precision-limited declared checks"
                )
        verify_run(root)
        return result
    finally:
        table.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--store", help="existing complete sealed kernel store")
    parser.add_argument(
        "--engine-config", help="optional complete sealed depth-engine configuration"
    )
    parser.add_argument("--repo", default=str(Path(__file__).resolve().parents[3]))
    parser.add_argument(
        "--out", required=True, help="new validation directory outside the store"
    )
    parser.add_argument(
        "--config",
        help="explicit finite-case JSON; default is the declared stratified pilot",
    )
    args = parser.parse_args(argv)
    config = json.loads(Path(args.config).read_text()) if args.config else None
    engine = read_json(args.engine_config) if args.engine_config else None
    store = args.store or (engine["store"]["path"] if engine else None)
    if store is None:
        parser.error("--store or --engine-config is required")
    summary = run_sealed_store_validation(
        store,
        args.out,
        config=config,
        repo=args.repo,
        engine_config=engine,
        config_path=args.config,
        engine_path=args.engine_config,
    )
    print(json.dumps(summary, indent=2, allow_nan=False))
    return 0 if summary["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
