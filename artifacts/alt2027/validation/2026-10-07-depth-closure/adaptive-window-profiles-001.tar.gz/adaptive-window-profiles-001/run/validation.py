"""Saved-profile comparisons for the isolated bounded upper-window fix."""
import gzip
import json
import shutil
import time
from dataclasses import replace
from pathlib import Path

import numpy as np

from lsa.alt.artifacts import environment, sha256, write_json
from lsa.alt.depth import DepthEvaluator, StoreConfig

root = Path.cwd()
original_root = root.parent / "github-cleanup"
original = original_root / "output/alt2027/depth-calibration-20261007/shard-3"
out = root / "output/alt2027/adaptive-window-profiles-001"
out.mkdir(parents=True, exist_ok=False)
shutil.copy2(__file__, out / "validation.py")
source_paths = [root / "src/lsa/alt/depth.py"] + list((root / "src/lsa/alt/_vendor/pmwm").glob("*.py"))
hashes = {str(p.relative_to(root)): sha256(p) for p in source_paths}
write_json(out / "source-start.json", hashes)
write_json(out / "environment.json", environment())
base_engine = json.loads((original / "default-engine.json").read_text())
store_path = json.loads((original_root / "output/alt2027/engine-candidate.json").read_text())["store"]["path"]
base = StoreConfig(path=store_path, **base_engine["store"])
profiles = {}
for index in (0, 2, 3):
    result = json.loads((original / f"result-{index:03d}.json").read_text())
    source = original / f"case-{index:03d}.npz"
    assert sha256(source) == result["sample_sha256"]
    shutil.copy2(source, out / source.name)
    with np.load(source, allow_pickle=False) as data:
        profiles[result["id"]] = (data["counts"], data["target"], index)
specifications = {
    "adaptive35": base,
    "fixed60": replace(base, u_max=60, maximum_u_max=60),
    "fixed80": replace(base, u_max=80, maximum_u_max=80),
    "refined80": replace(base, u_max=80, maximum_u_max=80, grid_step=.01,
                         minimum_grid_step=.00125, significance_gap=45),
    "fixed35": replace(base, maximum_u_max=35),
}
records = {}
for setting, config in specifications.items():
    directory = out / setting
    directory.mkdir()
    with DepthEvaluator(mode="store", store=config, prediction_tolerance=1e-7) as engine:
        write_json(directory / "engine.json", engine.configuration)
        for name, (counts, target, index) in profiles.items():
            # Fixed35 is the unchanged-case control, not another known failure rerun.
            if setting == "fixed35" and index != 0:
                continue
            start = time.perf_counter()
            result = engine.prediction_by_count(len(counts), counts[counts > 0], depths=[80])
            q = result.component_probabilities[0]
            mass = np.array([target[counts == c].sum() for c in result.counts])
            negative_entropy = np.sum(target[target > 0]*np.log2(target[target > 0]))
            record = {"case": name, "setting": setting, "depths": [80],
                      "component_log_evidence": result.component_log_evidence.tolist(),
                      "count_values": list(result.counts), "raw_probabilities": q.tolist(),
                      "raw_mass": float(q @ result.multiplicities),
                      "component_kl_bits": float(negative_entropy-mass @ np.log2(q)),
                      "diagnostics": result.diagnostics, "seconds": time.perf_counter()-start}
            write_json(directory / (name+".json"), record)
            records[name, setting] = record
            print(name, setting, "mass", record["raw_mass"], "upper",
                  result.diagnostics["base"]["components"][0]["actual_u_max"], flush=True)
comparisons = []
for name in profiles:
    pairs = [("adaptive35", "fixed60"), ("adaptive35", "fixed80"),
             ("adaptive35", "refined80"), ("fixed80", "refined80")]
    if profiles[name][2] == 0:
        pairs.append(("adaptive35", "fixed35"))
    for left, right in pairs:
        a, b = records[name, left], records[name, right]
        assert a["count_values"] == b["count_values"]
        evidence = float(abs(np.array(a["component_log_evidence"])-b["component_log_evidence"])[0])
        kl = abs(a["component_kl_bits"]-b["component_kl_bits"])
        q = float(np.max(np.abs(np.log2(np.array(a["raw_probabilities"])/b["raw_probabilities"]))))
        comparisons.append({"case": name, "left": left, "right": right,
                            "evidence_difference_nats": evidence, "kl_difference_bits": kl,
                            "maximum_log_predictive_difference_bits": q,
                            "passed": evidence/np.log(2) <= 1e-5 and kl <= 1e-5 and q <= 1e-5})
with gzip.open(original / "evaluation-000.json.gz", "rt") as stream:
    old = json.load(stream)["default"]
index = old["depths"].index(80)
new = records["zipf_1.5-n1000", "adaptive35"]
old_unchanged = {
    "case": "zipf_1.5-n1000", "depth": 80,
    "old_evaluation_sha256": sha256(original / "evaluation-000.json.gz"),
    "evidence_bitwise_equal": old["component_log_evidence"][index] == new["component_log_evidence"][0],
    "probabilities_bitwise_equal": np.array_equal(old["component_probabilities"][index], new["raw_probabilities"]),
    "window_expansions": new["diagnostics"]["base"]["components"][0]["window_expansions"],
}
final_hashes = {str(p.relative_to(root)): sha256(p) for p in source_paths}
passed = all(c["passed"] for c in comparisons) and hashes == final_hashes
passed = passed and old_unchanged["evidence_bitwise_equal"] and old_unchanged["probabilities_bitwise_equal"]
summary = {"status": "passed" if passed else "failed", "comparisons": comparisons,
           "previously_passing_case": old_unchanged, "source_unchanged": hashes == final_hashes,
           "source_at_finish": final_hashes, "normalization_applied": False,
           "maximum_raw_mass_error": max(abs(r["raw_mass"]-1) for r in records.values()),
           "scope": "three saved profiles, depth80 only, no model-grid/tolerance change"}
write_json(out / "summary.json", summary)
write_json(out / "files.json", {str(p.relative_to(out)): {"sha256": sha256(p), "bytes": p.stat().st_size}
                               for p in sorted(out.rglob("*")) if p.is_file()})
print(json.dumps(summary), flush=True)
raise SystemExit(0 if passed else 1)
