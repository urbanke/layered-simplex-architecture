import hashlib
import json
import pathlib
import sys
import numpy as np
from probe import CASES, NODES, evaluate

root = pathlib.Path(__file__).resolve().parent
mac = json.loads((root/'mac-comparison/probe.json').read_text())
linux = json.loads((root/'linux-comparison-probe.json').read_text())
reference = json.loads((root/'mp80-reference.json').read_text())
failed = json.loads((root/'failed-run-summary.json').read_text())
ra = np.load(root/'mac-comparison/rules.npz')
rb = np.load(root/'linux-comparison-rules.npz')
rh = np.load(root/'mp80-rules.npz')
summary = {
    'diagnosis': 'Platform-dependent Gauss-Legendre weight errors dominate the strict kernel refinement difference.',
    'mechanism': 'SciPy 1.18 _gen_roots_and_weights computes a derivative before Newton refinement of nodes and reuses that old derivative in weights. Recomputing Legendre weights at the returned nodes removes this error source.',
    'repair': 'Use the returned roots and Pn derivative evaluated at those final roots; compute 2/((1-x*x)*derivative**2), restore symmetry and quadrature weight sum 2. All scientific tolerances remain unchanged.',
    'source_commit_failed': 'cc1524a636a5f1996b4fbff1668c477ed0e989b8',
    'repair_commit': 'f0a5ebd',
    'linux_probe_jobs': [40157333, 40158239],
    'initial_failure_unchanged': failed['source_unchanged'],
    'failed_profiles': {p['target']: p['failed'] for p in failed['profiles']},
    'failed_components': sum(p['failed'] for p in failed['profiles']),
    'default_components_passed': sum(p['passed_by_setting'].get('default',0) for p in failed['profiles']),
    'strict_components_passed': sum(p['passed_by_setting'].get('strict',0) for p in failed['profiles']),
    'strict_kernel_log_tolerance': failed['strict_settings']['kernel_log_tolerance'],
    'reference': '80-digit Newton/Legendre recurrence rules with analytic moment checks; independent E-coordinate integral at 60 and 80 digits. Reference tails beyond 2 exp(v) are bounded by exp(-2**w-2 exp(v)) for r=0.',
    'rule_metrics': {}, 'kernel_metrics': {}, 'cross_platform_rules_on_mac': []}
for platform, rules in [('mac',ra),('linux',rb)]:
    summary['rule_metrics'][platform] = {}
    for family in ['scipy','numpy','refreshed']:
        metrics = []
        for n in NODES:
            x=rules[f'{family}_x_{n}'];w=rules[f'{family}_w_{n}']
            metrics.append(dict(nodes=n, max_node_error=float(np.max(abs(x-rh[f'x_{n}']))),
                max_weight_abs_error=float(np.max(abs(w-rh[f'w_{n}']))),
                max_weight_rel_error=float(np.max(abs(w/rh[f'w_{n}']-1))),
                max_test_moment_error=max(abs(float(w@x**k)-2/(k+1)) for k in [2,20,50])))
        summary['rule_metrics'][platform][family]=metrics
for platform, values in [('mac',mac),('linux',linux)]:
    summary['kernel_metrics'][platform]={}
    for family, cases in values['families'].items():
        metrics=[]
        for ref,case in zip(reference['kernels'],cases):
            truth=float(ref['log_value'])
            metrics.append(dict(r=case['r'],w=case['w'],v=case['v'],
                nodes=[dict(nodes=row['nodes'],log_value=row['log_value'],error_nats=row['log_value']-truth) for row in case['rows']],
                last_refinement_nats=abs(case['rows'][-1]['log_integral']-case['rows'][-2]['log_integral'])))
        summary['kernel_metrics'][platform][family]=metrics
for case, original in zip(CASES,linux['families']['scipy']):
    swapped=evaluate(*case,lambda n:(rb[f'scipy_x_{n}'],rb[f'scipy_w_{n}']))
    summary['cross_platform_rules_on_mac'].append(dict(r=case[0],w=case[1],v=case[2],
        max_log_difference_nats=max(abs(x['log_value']-y['log_value']) for x,y in zip(swapped['rows'],original['rows']))))
(root/'diagnosis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['rule_metrics','kernel_metrics']},indent=2))
