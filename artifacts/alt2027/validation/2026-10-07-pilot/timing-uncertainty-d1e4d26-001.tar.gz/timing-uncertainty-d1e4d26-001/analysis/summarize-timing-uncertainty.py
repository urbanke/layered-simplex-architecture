"""Read the frozen pilot records and summarize every method/pair symmetrically."""
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys

from lsa.alt.artifacts import verify_run


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scalar(value):
    return "NA" if value is None else f"{value:.12g}"


def main(run, out):
    record = verify_run(run)
    if record["purpose"] != "validation" or record["status"] != "complete":
        raise ValueError("expected a complete validation-purpose pilot")
    summary = json.loads((run / "data/summary.json").read_text())
    trials = [json.loads(line) for line in (run / "data/trials.jsonl").read_text().splitlines()]
    preparation = [json.loads(line) for line in (run / "data/batching.jsonl").read_text().splitlines()]
    config = summary["config"]
    out.mkdir(parents=True, exist_ok=False)
    method_rows = ["target\tn\tmethod\tstatus\tmean_bits\tSE_bits\tfinite_trials\tinfinite_trials\tundefined_trials"]
    pair_rows = ["target\tn\tleft_method\tright_method\tstatus\tmean_left_minus_right_bits\tpaired_SE_bits\tfinite_trials\tinfinite_trials\tundefined_trials"]
    for target in config["targets"]:
        for n in config["n_values"]:
            cell = summary["targets"][target][str(n)]
            for method in config["methods"]:
                result = cell["methods"][method]
                method_rows.append("\t".join(map(str, [target, n, method, result["status"],
                    scalar(result["mean_bits"]), scalar(result["se_bits"]),
                    result["counts"]["finite"], result["counts"]["infinite"], result["counts"]["undefined"]])))
            for i, left in enumerate(config["methods"]):
                for right in config["methods"][i+1:]:
                    result = cell["paired_differences"][f"{left}_minus_{right}"]
                    pair_rows.append("\t".join(map(str, [target, n, left, right, result["status"],
                        scalar(result["mean_bits"]), scalar(result["se_bits"]),
                        result["counts"]["finite"], result["counts"]["infinite"], result["counts"]["undefined"]])))
    (out / "methods.tsv").write_text("\n".join(method_rows) + "\n")
    (out / "all-paired-differences.tsv").write_text("\n".join(pair_rows) + "\n")
    timing = {
        "recorded_run_seconds": (datetime.fromisoformat(record["finished_utc"])-datetime.fromisoformat(record["started_utc"])).total_seconds(),
        "benchmark_scoring_seconds": summary["seconds"],
        "shared_preparation_seconds": summary["batching"]["shared_preparation_seconds"],
        "per_trial_scoring_seconds_sum": sum(row["seconds"] for row in trials),
        "timing_scope": "Run timer starts after numerical-store opening. Per-trial timers exclude shared depth preparation; benchmark total includes it. Concurrent checks may affect wall time.",
        "cohorts": [{"targets": sorted({sample["target_id"] for sample in row["samples"]}),
                     "n": row["n"], "trials": len(row["samples"]),
                     "unique_profiles": row["preparation"]["unique_profiles"],
                     "seconds": row["preparation"]["seconds"]} for row in preparation],
        "maximum_raw_component_normalization_error": max(
            diag["raw_mass_error"] for row in trials
            for diag in row["diagnostics"]["depth"]["component_normalization"]),
        "maximum_raw_mixture_normalization_error": max(
            row["diagnostics"]["lsa_depth_mixture"]["raw_mass_error"] for row in trials),
        "trial_count": len(trials), "methods_per_trial": len(config["methods"]),
        "source_commit": record["source"]["commit"], "source_tree_sha256": record["source"]["tree_sha256"],
        "source_dirty": record["source"]["dirty"], "purpose": record["purpose"],
        "run_manifest_sha256": digest(run / "manifest.json"),
        "summary_sha256": digest(run / "data/summary.json"),
        "analysis_script_sha256": digest(Path(__file__)),
        "production_protocol_changed": False,
        "uncertainty": "Sample standard deviation/sqrt(20), ddof=1. Paired SE uses within-trial loss differences. Every method and every unordered pair uses the same rule; nonfinite outcomes are retained, not dropped.",
        "interpretation": "Timing/uncertainty subset only. No ranking or production result; two targets do not describe all paper-domain runtimes or uncertainty."}
    (out / "timing-and-scope.json").write_text(json.dumps(timing, indent=2) + "\n")
    print(json.dumps(timing, indent=2))
    print("\n".join(method_rows))


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
