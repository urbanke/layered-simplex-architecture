"""Independently check every original failed kernel, preserving its settings."""
import hashlib
import inspect
import json
import pathlib
import re
import mpmath as mp
from lsa.alt.powers import PowerSettings, log_scaled_kernel

root=pathlib.Path(__file__).resolve().parent
original=json.loads((root/'failed-run-summary.json').read_text())
settings=PowerSettings(**original['strict_settings'])
rows=[]
for profile in original['profiles']:
    for failure in profile['failures']:
        match=re.search(r'r=(\d+), w=(\d+), v=([^,]+),',failure['error'])
        r,w,v=int(match[1]),int(match[2]),float(match[3])
        assert r==0
        actual,diagnostics=log_scaled_kernel(r,w,v,settings=settings)
        with mp.workdps(60):
            b=mp.exp(mp.mpf(v))
            value=mp.quad(lambda x:mp.exp(-x-(x/b)**w),
                          [0,b/2,b*mp.mpf('.9'),b,b*mp.mpf('1.1'),b*mp.mpf('1.5'),2*b])
            expected=mp.log(value);error=abs(mp.mpf(actual)-expected)
            tail=mp.exp(-mp.power(2,w)-2*b)/value
            assert tail<mp.mpf('1e-60')
            rows.append(dict(target=profile['target'],r=r,w=w,v=v,
                expected_log_value=str(expected),actual_log_value=actual,
                absolute_error_nats=float(error),diagnostics=diagnostics))
        print(profile['target'],w,rows[-1]['absolute_error_nats'],flush=True)
report=dict(status='passed' if max(r['absolute_error_nats'] for r in rows)<3e-14 else 'failed',
    scope='All 55 exact kernels that failed the original Linux calibration; local repaired evaluator with independent 60-digit E-domain references.',
    max_absolute_error_nats=max(r['absolute_error_nats'] for r in rows),
    max_refinement_log_difference_nats=max(r['diagnostics']['refinement_log_difference'] for r in rows),
    scientific_source_sha256=hashlib.sha256(pathlib.Path(inspect.getfile(log_scaled_kernel)).read_bytes()).hexdigest(),
    settings=original['strict_settings'],cases=rows)
(root/'all-failed-kernels-independent.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'],report['max_absolute_error_nats'],flush=True)
